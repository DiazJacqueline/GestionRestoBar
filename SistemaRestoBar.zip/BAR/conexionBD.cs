﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace BAR
{


    public static class Conexion //static sirve para que la clase no necesite ser instanciado (se puede llamar con el nombre)
    {
        //atributos (todos deben ser static)
        private static string _connectionString = "datasource=127.0.0.1;port=3306;username=root;password=41259143;database=BD_SistemaBar;";
        //GET
        public static string ConnectionString
        {
            get { return _connectionString; }
        }
    }
}
