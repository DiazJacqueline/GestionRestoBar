﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography.X509Certificates;

namespace BAR
{
    public partial class Caja : Form
    {
        Gastos caja = new Gastos();
        public Caja()
        {
            InitializeComponent();
            

        }

        private void Caja_Load(object sender, EventArgs e)
        {
            string cadena = "SELECT * FROM Caja;";
            CargarGrillaCaja(cadena);

            string qry = "SELECT * FROM TotalDia;";
            CargarDatagrid(qry);
            SumaTotal();

        }
        private void CargarGrillaCaja(string qry)
        {
            //Limpiamos el datagrid
            dgvCaja.Rows.Clear();

            MySqlConnection con = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand cmd = new MySqlCommand(qry, con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, con);
            DataSet ds = new DataSet();
            data.Fill(ds);

            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                
                dgvCaja.Rows.Add();
                dgvCaja.Rows[fila].Cells["ingresos"].Value = dr["ingresos"].ToString();
                dgvCaja.Rows[fila].Cells["mesa"].Value = dr["mesa"].ToString();
                dgvCaja.Rows[fila].Cells["id_mozo"].Value = dr["codigo_Emp"].ToString();
                dgvCaja.Rows[fila].Cells["gasto"].Value = dr["egresos"].ToString();
                dgvCaja.Rows[fila].Cells["Detalle"].Value = dr["Gastos"].ToString();

                fila++;
            }
            
        }
        public void SumaTotal()
        {
            double total = 0;
            double gastos = 0;
            double TotalDia = 0;

            foreach (DataGridViewRow row in dgvCaja.Rows)
            {
                total += Convert.ToDouble(row.Cells["ingresos"].Value);
                gastos += Convert.ToDouble(row.Cells["gasto"].Value);
            }
            TotalDia = total - gastos;

            lblGastos.Text= "$ "+ gastos.ToString();
            lblTotal.Text= "$ "+total.ToString();
            lblTotalDia.Text= TotalDia.ToString();

        }
       

            private void btnSalirCaja_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       

        private void btnGuardarGasto_Click(object sender, EventArgs e)
        {
            //Asignamos los datos al objeto

            caja.Detalle = txtDetalle.Text;
            caja.Monto =double.Parse(txtMonto.Text);

            //Si es un empleado nuevo tiene el id en 0
            if (caja.IdCaja == 0)
            {
                //Guardamos los datos con el método guardar del objeto empleado
                caja.GuardarGasto();
            }
            else
            {
                //Actualizamos los datos
                caja.Actualizar();
            }

            //Recargamos la grilla
            string cadena = "SELECT * FROM Caja;";
            CargarGrillaCaja(cadena);
            SumaTotal();


            //Limpiamos los TextBox

            txtDetalle.Clear();
            txtMonto.Clear();

            caja.IdCaja = 0;
        }

        private void btnCerrarCaja_Click(object sender, EventArgs e)
        {
            double total = 0;
            double gastos = 0;
            double TotalDia = 0;
            string fecha;
            fecha = DateTime.Today.ToString("yyyy/MM/dd");

            foreach (DataGridViewRow row in dgvCaja.Rows)
            {
                total += Convert.ToDouble(row.Cells["ingresos"].Value);
                gastos += Convert.ToDouble(row.Cells["gasto"].Value);
            }
            TotalDia = total - gastos;

            lblGastos.Text = "$ " + gastos.ToString();
            lblTotal.Text = "$ " + total.ToString();
            lblTotalDia.Text = TotalDia.ToString();
            //--------------------------------------
            string cadena = "INSERT INTO TotalDia " +
                                "( fecha, ingresoTotal, gastoTotal, TotalCaja) " +
                                "VALUES " +
                                $"('{fecha}', '{total}','{gastos}','{TotalDia}');";

            //Creamos el objeto para la conexión
            //Conexion cnx = new Conexion();

            MySqlConnection con = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand cmd = new MySqlCommand(cadena, con);
            cmd.CommandType = CommandType.Text;
            
            //Declaramos la variable para comandos
            // MySqlCommand comando = new MySqlCommand(cadena, cnx.sql_conn);

            try
            {
                con.Open();

                //Insertamos los datos
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

            dgvCaja.Rows.Clear();
            SumaTotal();
            caja.EliminarDetalledeCaja();
            string qry = "SELECT * FROM TotalDia;";
            CargarDatagrid(qry);

        }

        public void CargarDatagrid(string qry)
        {
            //Limpiamos el datagrid
            dgvTotales.Rows.Clear();

            //Objeto de conexión
            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand comando = new MySqlCommand(qry, cnx);
            comando.CommandType = CommandType.Text;
            cnx.Open();

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

       

            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {

                dgvTotales.Rows.Add();
                dgvTotales.Rows[fila].Cells["Fecha"].Value = dr["fecha"].ToString();
                dgvTotales.Rows[fila].Cells["ingreso"].Value = dr["ingresoTotal"].ToString();
                dgvTotales.Rows[fila].Cells["gastos"].Value = dr["gastoTotal"].ToString();
                dgvTotales.Rows[fila].Cells["total"].Value = dr["TotalCaja"].ToString();
                fila++;
            }

           
        }
    }
    public class Gastos
    {
        //atributos
        int _idCaja;
        string _detalle;
        double _monto;
        string _fecha;
        


        //metodos
        public string Fecha
        {
            get { return _fecha; }
            set { _fecha = value; }
        }
        public int IdCaja
        {
            get { return _idCaja; }
            set { _idCaja = value; }
        }
        public string Detalle
        {
           get { return _detalle; }
            set { _detalle = value; }
        }
        public double Monto
        {
            get { return _monto; }
            set { _monto = value; }
        }
        //constructores
         public Gastos()
        {
            _fecha = DateTime.Today.ToString("yyyy/MM/dd");
            this._detalle = "";
            this._monto = 0;
        }

        public void GuardarGasto()
        {
          

            string cadena = "INSERT INTO Caja " +
                            "( egresos, Gastos, ingresos,TotalDia, fecha) " +
                            "VALUES " +
                            $"('{this._monto}', '{this._detalle}', 0, 0, '{_fecha}');";
            MySqlConnection con = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand cmd = new MySqlCommand(cadena, con);
            cmd.CommandType = CommandType.Text;
            

            //Declaramos la variable para comandos

            MySqlCommand comanado = new MySqlCommand(cadena, con);

            try
            {
                con.Open();

                //Insertamos los datos
                // comando.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        public void Actualizar()
        {
            string qry = $"UPDATE Caja SET id_caja = '{this._idCaja}', egresos = '{this._monto}', Gastos = {this._monto} WHERE id_caja = {this._idCaja};";

            //Creamos el objeto para la conexión
            
            MySqlConnection con = new MySqlConnection(Conexion.ConnectionString);
            //Declaramos la variable para comandos

            MySqlCommand cmd = new MySqlCommand(qry, con);

            cmd.CommandType = CommandType.Text;
            con.Open();//




            try
            {
                con.Open();

                //Insertamos los datos
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
       
        public void EliminarDetalledeCaja()
        {
            string fecha;
            fecha = DateTime.Today.ToString("yyyy/MM/dd");


            string qry = $"Delete from Caja where fecha = '{fecha}'";
            MySqlConnection con = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand cmd = new MySqlCommand(qry, con);
            cmd.CommandType = CommandType.Text;


            try
            {
                con.Open();

                //Insertamos los datos
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

    }
}
    

