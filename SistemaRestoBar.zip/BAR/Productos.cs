﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography.X509Certificates;



namespace BAR
{

    public partial class Productos : Form

    {
        Producto prod = new Producto();
        public Productos()
        {

            InitializeComponent();
            CargarCategorias();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Productos_Shown(object sender, EventArgs e)
        {
            //Ponemos el foco en el primer TextBox
           txtNombreProd.Focus();
        }

        private void btnGuardarProducto_Click(object sender, EventArgs e)
        {
           
            //Acá iria la validación de los datos ingresados por el usuario

            //Asignamos los datos al objeto
            prod.Nombre = txtNombreProd.Text;
            prod.Precio = double.Parse(txtPrecioProd.Text);
            prod.Stock = int.Parse(txtStock.Text);
            prod.Categoria = int.Parse(cbxCategoria.SelectedValue.ToString());
            //Si es un producto nuevo tiene el id en 0
            if (prod.Id == 0)
            {
                //Guardamos los datos con el método guardar del objeto producto
                prod.Guardar();
            }
            else
            {
                //Actualizamos los datos
                prod.Actualizar();
            }

            //Recargamos la grilla
            string cadena = "SELECT * FROM Productos;";
            CargarDatagrid(cadena);

            //Limpiamos los TextBox
            txtNombreProd.Clear();
            txtPrecioProd.Clear();
            //txtStock.Clear();


            //Volvemos a poner el id del empleado en 0
            prod.Id = 0;

            
        }

        private void Productos_Load(object sender, EventArgs e)
        {
            string cadena = "SELEC" +
                "T * FROM Productos;";
            CargarDatagrid(cadena);
        }
        public void CargarDatagrid(string qry)
        {

            //Limpiamos el datagrid
            dgvProductos.Rows.Clear();

            //Objeto de conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);


            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                //MessageBox.Show(dr["Apellido"].ToString());
                dgvProductos.Rows.Add();
                dgvProductos.Rows[fila].Cells["Id_prod"].Value = dr["id_prod"].ToString();
                dgvProductos.Rows[fila].Cells["Producto"].Value = dr["nom_prod"].ToString();
                dgvProductos.Rows[fila].Cells["Precio"].Value = dr["precio_prod"].ToString();
                dgvProductos.Rows[fila].Cells["Stock"].Value = dr["Stock"].ToString();
                dgvProductos.Rows[fila].Cells["Categoria"].Value = dr["id_categoria"].ToString();
                fila++;
            }
        }

        private void btnEliminarProd_Click(object sender, EventArgs e)
        {
            //Acá habría que preguntar al usuario si confirma la eliminación
            //Borramos el registro con el método del empleado
            prod.Eliminar();

            //Recargamos la grilla
            string cadena = "SELECT * FROM Productos";
            CargarDatagrid(cadena);
        }

        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Obtenemos el Id del empleado en el que se hizo click
            string valor = dgvProductos.Rows[e.RowIndex].Cells["Id_prod"].Value.ToString();
            int valor_int = Int32.Parse(valor);
            prod.Id = valor_int;
        }



        private void btnModificar_Click(object sender, EventArgs e)
        {
            //Asignamos los datos a los campos del objeto
            prod.CargarDatos();

            //Mostramos los datos
            txtNombreProd.Text = prod.Nombre;
            txtPrecioProd.Text = prod.Precio.ToString();
            txtStock.Text = prod.Stock.ToString();

        }

       

        private void btnBascarProd_Click(object sender, EventArgs e)
        {
            string texto = txtBuscarProd.Text;

            //Cadena de consulta
            string qry = $"SELECT * FROM Productos WHERE nom_prod like '{texto}%';";

            CargarDatagrid(qry);
        }

        private void CargarCategorias()
        {
            cbxCategoria.DataSource = null;
            cbxCategoria.Items.Clear(); //limpia mi combo box
            string sql = "select id_categoria, descripcion_cat FROM Categoria";


            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            cnx.Open();
         
           

            try
            {
                //Declaramos la variable para comandos
                MySqlCommand comando = new MySqlCommand(sql, cnx);
                MySqlDataAdapter data = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                data.Fill(dt);
                //Insertamos los datos
             
                cbxCategoria.ValueMember = "id_categoria";
                cbxCategoria.DisplayMember = "descripcion_cat";
                cbxCategoria.DataSource = dt;

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al cargar categoria"+ex.Message);
            }
            finally
            {
                cnx.Close();
            }

        }

    }




    //-------------------------------------------------------------------------///


    public class Producto
    {
        //Atributos de la clase
        private int _id;
        private string _nombre;
        private double _precio;
        private float _stock;
        private int _categoria;

        //Metodos SET y GET
        public int Categoria
        {
            get { return _categoria; }
            set { _categoria = value; }
        }
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }
        public double Precio
        {
            get { return _precio; }
            set { _precio = value; }
        }
        public float Stock
        {
            get { return _stock; }
            set { _stock = value; }
        }

        //contructor por defecto
        public Producto()
        {
            _id = 0;
            _nombre = "";
            _precio = 0;
            _stock = 0;
            _categoria = 0;
        }

        public void Guardar()
        {
            string cadena = "INSERT INTO Productos " +
                            "(nom_prod, precio_prod,stock, id_categoria) " +
                            "VALUES " +
                            $"('{this._nombre}', '{this._precio}', {this._stock} = 0, {this._categoria});";


            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand comando = new MySqlCommand(cadena, cnx);
            comando.CommandType = CommandType.Text;
           
            //Creamos el objeto para la conexión
            //Conexion cnx = new Conexion();

            //Declaramos la variable para comandos
            // MySqlCommand comando = new MySqlCommand(cadena, cnx.sql_conn);

            try
            {
                cnx.Open();

                //Insertamos los datos
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }



        public void Eliminar()
        {
            //Cadena de consulta
            string qry = $"DELETE FROM Productos WHERE id_prod = {this._id};";

            //Creamos el objeto para la conexión
            //Declaramos la variable para comandos
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand comando = new MySqlCommand(qry, cnx);
            comando.CommandType = CommandType.Text;
            

            try
            {
                cnx.Open();

                //Ejecutamos la consulta
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
            
        }



        public void CargarDatos()
        {
            //Cadena de consulta
            string qry = $"SELECT * FROM Productos WHERE id_prod = {this._id}";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand comando = new MySqlCommand(qry, cnx);
            comando.CommandType = CommandType.Text;
            cnx.Open();

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

            //Asignamos los valores
            DataRow dr = ds.Tables[0].Rows[0];
            this._nombre = dr["nom_prod"].ToString();
            this._precio = (double)dr["precio_prod"];
            this._stock = (int)dr["Stock"];
            this._categoria = (int)dr["id_categoria"];
        }
        public void Actualizar()
        {
            string qry = $"UPDATE Productos SET nom_prod = '{this._nombre}', precio_prod = '{this._precio}', stock = {this._stock}, id_categoria = '{this._categoria}' WHERE id_prod = {this._id};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);

            try
            {
                cnx.Open();

                //Insertamos los datos
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }


    }
}

       
         
 

