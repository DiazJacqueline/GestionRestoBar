﻿namespace BAR
{
    partial class FormEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvEmpleados = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNombreEmp = new System.Windows.Forms.TextBox();
            this.txtApellidoEmp = new System.Windows.Forms.TextBox();
            this.txtTelefonoEmp = new System.Windows.Forms.TextBox();
            this.btnGuardarEmp = new System.Windows.Forms.Button();
            this.btnModificarEmp = new System.Windows.Forms.Button();
            this.btnEliminarEmp = new System.Windows.Forms.Button();
            this.btnSalirEmp = new System.Windows.Forms.Button();
            this.id_empleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Num_tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvEmpleados
            // 
            this.dgvEmpleados.AllowUserToAddRows = false;
            this.dgvEmpleados.AllowUserToDeleteRows = false;
            this.dgvEmpleados.BackgroundColor = System.Drawing.Color.PaleTurquoise;
            this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_empleado,
            this.Nombre,
            this.Apellido,
            this.Num_tel});
            this.dgvEmpleados.Location = new System.Drawing.Point(12, 52);
            this.dgvEmpleados.Name = "dgvEmpleados";
            this.dgvEmpleados.ReadOnly = true;
            this.dgvEmpleados.Size = new System.Drawing.Size(462, 306);
            this.dgvEmpleados.TabIndex = 0;
            this.dgvEmpleados.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmpleados_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(132, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "EMPLEADOS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(573, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingresar nuevo empleado";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(541, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nombre";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(541, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Apellido";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(502, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Num de Telefono";
            // 
            // txtNombreEmp
            // 
            this.txtNombreEmp.Location = new System.Drawing.Point(626, 146);
            this.txtNombreEmp.Name = "txtNombreEmp";
            this.txtNombreEmp.Size = new System.Drawing.Size(162, 20);
            this.txtNombreEmp.TabIndex = 6;
            // 
            // txtApellidoEmp
            // 
            this.txtApellidoEmp.Location = new System.Drawing.Point(626, 109);
            this.txtApellidoEmp.Name = "txtApellidoEmp";
            this.txtApellidoEmp.Size = new System.Drawing.Size(162, 20);
            this.txtApellidoEmp.TabIndex = 7;
            // 
            // txtTelefonoEmp
            // 
            this.txtTelefonoEmp.Location = new System.Drawing.Point(634, 184);
            this.txtTelefonoEmp.Name = "txtTelefonoEmp";
            this.txtTelefonoEmp.Size = new System.Drawing.Size(142, 20);
            this.txtTelefonoEmp.TabIndex = 8;
            // 
            // btnGuardarEmp
            // 
            this.btnGuardarEmp.BackColor = System.Drawing.Color.GreenYellow;
            this.btnGuardarEmp.Location = new System.Drawing.Point(596, 273);
            this.btnGuardarEmp.Name = "btnGuardarEmp";
            this.btnGuardarEmp.Size = new System.Drawing.Size(130, 44);
            this.btnGuardarEmp.TabIndex = 9;
            this.btnGuardarEmp.Text = "Guardar Empleado";
            this.btnGuardarEmp.UseVisualStyleBackColor = false;
            this.btnGuardarEmp.Click += new System.EventHandler(this.btnGuardarEmp_Click);
            // 
            // btnModificarEmp
            // 
            this.btnModificarEmp.BackColor = System.Drawing.Color.DarkCyan;
            this.btnModificarEmp.Location = new System.Drawing.Point(54, 364);
            this.btnModificarEmp.Name = "btnModificarEmp";
            this.btnModificarEmp.Size = new System.Drawing.Size(118, 45);
            this.btnModificarEmp.TabIndex = 10;
            this.btnModificarEmp.Text = "Modificar";
            this.btnModificarEmp.UseVisualStyleBackColor = false;
            this.btnModificarEmp.Click += new System.EventHandler(this.btnModificarEmp_Click);
            // 
            // btnEliminarEmp
            // 
            this.btnEliminarEmp.BackColor = System.Drawing.Color.Salmon;
            this.btnEliminarEmp.Location = new System.Drawing.Point(226, 364);
            this.btnEliminarEmp.Name = "btnEliminarEmp";
            this.btnEliminarEmp.Size = new System.Drawing.Size(120, 45);
            this.btnEliminarEmp.TabIndex = 11;
            this.btnEliminarEmp.Text = "Elimianar Empleado";
            this.btnEliminarEmp.UseVisualStyleBackColor = false;
            this.btnEliminarEmp.Click += new System.EventHandler(this.btnEliminarEmp_Click);
            // 
            // btnSalirEmp
            // 
            this.btnSalirEmp.BackColor = System.Drawing.Color.Crimson;
            this.btnSalirEmp.Location = new System.Drawing.Point(668, 386);
            this.btnSalirEmp.Name = "btnSalirEmp";
            this.btnSalirEmp.Size = new System.Drawing.Size(94, 41);
            this.btnSalirEmp.TabIndex = 12;
            this.btnSalirEmp.Text = "Salir";
            this.btnSalirEmp.UseVisualStyleBackColor = false;
            this.btnSalirEmp.Click += new System.EventHandler(this.btnSalirEmp_Click);
            // 
            // id_empleado
            // 
            this.id_empleado.HeaderText = "Codigo de empleado";
            this.id_empleado.Name = "id_empleado";
            this.id_empleado.ReadOnly = true;
            this.id_empleado.Width = 70;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            this.Nombre.Width = 125;
            // 
            // Apellido
            // 
            this.Apellido.HeaderText = "Apellido";
            this.Apellido.Name = "Apellido";
            this.Apellido.ReadOnly = true;
            this.Apellido.Width = 125;
            // 
            // Num_tel
            // 
            this.Num_tel.HeaderText = "Numero de Telefono";
            this.Num_tel.Name = "Num_tel";
            this.Num_tel.ReadOnly = true;
            this.Num_tel.Width = 125;
            // 
            // FormEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSalirEmp);
            this.Controls.Add(this.btnEliminarEmp);
            this.Controls.Add(this.btnModificarEmp);
            this.Controls.Add(this.btnGuardarEmp);
            this.Controls.Add(this.txtTelefonoEmp);
            this.Controls.Add(this.txtApellidoEmp);
            this.Controls.Add(this.txtNombreEmp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvEmpleados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEmpleados";
            this.Text = "Empleados";
            this.Load += new System.EventHandler(this.FormEmpleados_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmpleados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNombreEmp;
        private System.Windows.Forms.TextBox txtApellidoEmp;
        private System.Windows.Forms.TextBox txtTelefonoEmp;
        private System.Windows.Forms.Button btnGuardarEmp;
        private System.Windows.Forms.Button btnModificarEmp;
        private System.Windows.Forms.Button btnEliminarEmp;
        private System.Windows.Forms.Button btnSalirEmp;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_empleado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num_tel;
    }
}