﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography.X509Certificates;

namespace BAR
{
    public partial class FormEmpleados : Form
    {
        //Creamos una instancia de empleado
        Empleado emp = new Empleado();
        public FormEmpleados()
        {
            InitializeComponent();
        }

        private void Empleados_Shown(object sender, EventArgs e)
        {
            //Foco en el primer TextBox
            txtNombreEmp.Focus();
        }

        private void FormEmpleados_Load(object sender, EventArgs e)
        {
            string cadena = "SELECT * FROM Empleados;";
            CargarDatagrid(cadena);
        }

        private void btnSalirEmp_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardarEmp_Click(object sender, EventArgs e)
        {
       
            //Asignamos los datos al objeto
            
            emp.Nombre = txtNombreEmp.Text;
            emp.Apellido = txtApellidoEmp.Text;
            emp.Tel = txtTelefonoEmp.Text;

            //Si es un empleado nuevo tiene el id en 0
            if (emp.IdEmp == 0)
            {
                //Guardamos los datos con el método guardar del objeto empleado
                emp.Guardar();
            }
            else
            {
                //Actualizamos los datos
                emp.Actualizar();
            }

            //Recargamos la grilla
            string cadena = "SELECT * FROM Empleados;";
            CargarDatagrid(cadena);

            
            //Limpiamos los TextBox

            txtNombreEmp.Clear();
            txtApellidoEmp.Clear();
            txtTelefonoEmp.Clear();

            //Volvemos a poner el id del empleado en 0
            emp.IdEmp = 0;
        }
        public void CargarDatagrid(string qry)
        {
            //Limpiamos el datagrid
            dgvEmpleados.Rows.Clear();

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand comando = new MySqlCommand(qry, cnx);//*
            comando.CommandType = CommandType.Text;
            cnx.Open();

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                
                dgvEmpleados.Rows.Add();
                dgvEmpleados.Rows[fila].Cells["id_empleado"].Value = dr["id_emp"].ToString();
                dgvEmpleados.Rows[fila].Cells["Nombre"].Value = dr["nombre_emp"].ToString();
                dgvEmpleados.Rows[fila].Cells["Apellido"].Value = dr["apellido_emp"].ToString();
                dgvEmpleados.Rows[fila].Cells["Num_tel"].Value = dr["num_tel_emp"].ToString();
                fila++;
            }
        }
        private void btnEliminarEmp_Click(object sender, EventArgs e)
        {
            //Acá habría que preguntar al usuario si confirma la eliminación
            //Borramos el registro con el método del empleado
            emp.Eliminar();

            //Recargamos la grilla
            string cadena = "SELECT * FROM Empleados";
            CargarDatagrid(cadena);
        }

        private void btnModificarEmp_Click(object sender, EventArgs e)
        {
            //Asignamos los datos a los campos del objeto
            emp.CargarDatos();

            //Mostramos los datos
            txtNombreEmp.Text = emp.Nombre;
            txtApellidoEmp.Text = emp.Apellido;
            txtTelefonoEmp.Text = emp.Tel;
        }

        private void dgvEmpleados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Obtenemos el Id del empleado en el que se hizo click
            string valor = dgvEmpleados.Rows[e.RowIndex].Cells["id_empleado"].Value.ToString();
            int valor_int = Int32.Parse(valor);
            emp.IdEmp = valor_int;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
    public class Empleado
        {
            int _idEmp;
            string _apellido;
            string _nombre;
            string _tel;

            public string Apellido
            {
                get { return _apellido; }
                set { _apellido = value; }
            }

            public int IdEmp
            {
                get { return _idEmp; }
                set { _idEmp = value; }
            }

            public string Nombre
            {
                get { return _nombre; }
                set { _nombre = value; }
            }

            public string Tel
            {
                get { return _tel; }
                set { _tel = value; }
            }

            public Empleado()
            {
                this._idEmp = 0;
                this._apellido = "";
                this._nombre = "";
                this._tel = "";
            }



            public void Guardar()
            {
                string cadena = "INSERT INTO Empleados " +
                                "( nombre_emp, apellido_emp , num_tel_emp) " +
                                "VALUES " +
                                $"('{this._nombre}', '{this._apellido}', {this._tel});";

              //Creamos el objeto para la conexión
              MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
              MySqlCommand comando = new MySqlCommand(cadena, cnx);
              comando.CommandType = CommandType.Text;
              

           

            try
                {
                    cnx.Open();

                    //Insertamos los datos
                    comando.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    cnx.Close();
                }
            }



            public void Eliminar()
            {
                //Cadena de consulta
                string qry = $"DELETE FROM Empleados WHERE id_emp = {this._idEmp};";

               //Creamos el objeto para la conexión
               MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
               MySqlCommand comando = new MySqlCommand(qry, cnx);
               comando.CommandType = CommandType.Text;
             

          
            try
                {
                    cnx.Open();

                    //Ejecutamos la consulta
                    comando.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    cnx.Close();
                }
            }



            public void CargarDatos()
            {
                //Cadena de consulta
                string qry = $"SELECT * FROM Empleados WHERE id_emp = {this._idEmp}";

                //Creamos el objeto para la conexión

               
               //Creamos el objeto para la conexión
               MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
               //Declaramos la variable para comandos
               MySqlCommand comando = new MySqlCommand(qry, cnx);
               comando.CommandType = CommandType.Text; //es necesario?
               cnx.Open();

               //Traemos los datos
               MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
               DataSet ds = new DataSet();
               data.Fill(ds);
               

                //Asignamos los valores
                 DataRow dr = ds.Tables[0].Rows[0];
                 this._nombre = dr["nombre_emp"].ToString();
                 this._apellido = dr["apellido_emp"].ToString();
                 this._tel = dr["num_tel_emp"].ToString();
            }



            public void Actualizar()
            {
                string qry = $"UPDATE Empleados SET nombre_emp = '{this._nombre}', apellido_emp = '{this._apellido}', num_tel_emp = {this._tel} WHERE id_emp = {this._idEmp};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);
            comando.CommandType = CommandType.Text;
            

            
           

                try
                {
                    cnx.Open();

                    //Insertamos los datos
                    comando.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    cnx.Close();
                }
            }
    }

}
