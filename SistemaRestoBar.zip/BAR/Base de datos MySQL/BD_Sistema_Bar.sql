create database BD_SistemaBar;
use BD_SistemaBar;
create table Empleados
(
id_emp int auto_increment primary key not null,
nombre_emp varchar (50),
apellido_emp varchar (50),
num_tel_emp varchar (20)
); 



create table Categoria
(
id_categoria int auto_increment primary key not null,
descripcion_cat varchar (30)
);

 create table Productos 
 (
 id_prod int auto_increment not null primary key,
 nom_prod varchar (60),
 precio_prod decimal (10,2),
 stock int,
 id_categoria int,
 foreign key (id_categoria) references Categoria(id_categoria)
 );
 
 create table Mesa_pedido
 (
 id_mesa int auto_increment primary key not null,
 nombre_mesa varchar(250),
 id_empleado int,
 foreign key (id_empleado) references Empleados(id_emp) 
 );
 
 create table Detalle
 (
 id_detalle int auto_increment primary key not null,
 fecha date,
 cantidad int,
 id_pedido int,
 id_empleado int,
 id_producto int,
 foreign key (id_pedido) references Mesa_pedido(id_mesa),
 foreign key (id_empleado) references Empleados(id_emp),
 foreign key (id_producto) references Productos(id_prod)
 );
 
 create table Caja
 (
 id_caja int auto_increment primary key not null,
 fecha date,
 ingresos decimal(10,2),
 egresos decimal(10,2)
 );
  insert into Categoria(descripcion_cat) values ("Comida");
   insert into Categoria(descripcion_cat) values ("Bebida");
   select * from Categoria;
   select * from Productos;
   select Categoria.descripcion_cat FROM Productos
   inner join Categoria on (Productos.id_categoria = Categoria.id_categoria);
select descripcion_cat from Categoria;
select * from Empleados;
select * from Mesa_pedido;
select * from Detalle;
select * from Productos;
DELETE FROM Mesa_Pedido WHERE id_empleado =8;
DELETE FROM Empleados WHERE id_emp =7;
 INSERT INTO Detalle(id_producto, cantidad ) VALUES (1, 2);
  use BD_SistemaBar;

describe Detalle;
describe productos;
select * from productos;
alter table Detalle add nombreProd varchar(150);
alter table Detalle add precioProd decimal(10,2);

ALTER TABLE Detalle RENAME column id_pedido TO id_mesa;

ALTER TABLE productos CHANGE COLUMN precio_produ precio_prod double;
ALTER TABLE Detalle CHANGE COLUMN precioProd precioProd double;

select * from detalle;
select * from productos;
select * from Mesa_pedido;
DELETE FROM Detalle WHERE id_producto = 19 and id_mesa = 34;
select * from Mesa_pedido;
delete from detalle where id_empleado=19;
delete from Mesa_pedido where id_empleado = 19;
delete from detalle where id_mesa=68;

ALTER TABLE Caja change column egresos egresos double;
select * from Caja;
delete from Caja where id_caja =27;
insert into Caja(ingresos) values (1500);
alter table Caja add mesa varchar(250);
alter table Caja add codigo_Emp int;
use BD_SistemaBar;
Insert Into Caja(ingresos, mesa, codigo_Emp) values (1500, "Nombre mesa", 23);
ALTER TABLE Caja CHANGE COLUMN fecha fecha datetime;