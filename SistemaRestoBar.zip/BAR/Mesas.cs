﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography.X509Certificates;

namespace BAR
{
    public partial class Mesas : Form
    {
        Mesas_Pedidos mesa = new Mesas_Pedidos();
        DetalleMesa detalle = new DetalleMesa();

        public Mesas()
        {
            InitializeComponent();
            CargarEmpleados();

        }

        private void Mesas_Load(object sender, EventArgs e)
        {
            string cadena = "SELECT" +
               " * FROM Mesa_pedido;";
            CargarDatagridMesas(cadena);
            //Hacemos que no haya ninguna fila auto seleccionada
            dgvMesas.ClearSelection();

            cadena = "SELECT * FROM productos;";
            CargarDataGridMercaderia(cadena);
            //Hacemos que no haya ninguna fila auto seleccionada
            dataGridView1.ClearSelection();
            SumaTotal();
        }



        private void SalirMesas_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        public void CargarDatagridMesas(string qry)
        {
            //Limpiamos el datagrid
            dgvMesas.Rows.Clear();

               //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
            MySqlCommand comando = new MySqlCommand(qry, cnx);
            comando.CommandType = CommandType.Text;
            cnx.Open();

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);


            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                dgvMesas.Rows.Add();
                dgvMesas.Rows[fila].Cells["id_mesa"].Value = dr["id_mesa"].ToString();
                dgvMesas.Rows[fila].Cells["NombreMesa"].Value = dr["nombre_mesa"].ToString();
                dgvMesas.Rows[fila].Cells["Mozo"].Value = dr["id_empleado"].ToString();

                fila++;
            }
        }



        private void btnAgregarMesa_Click(object sender, EventArgs e)
        {
            //abrir panel
            pnlMesas.Visible = true;
        }



        private void btnOkMesa_Click(object sender, EventArgs e)
        {

            //Asignamos los datos al objeto
            mesa.NombreMesa = txtNombreMesa.Text;
            mesa.Mozo = int.Parse(cbxMozos.SelectedValue.ToString());

            //Guardamos los datos
            mesa.GuardarMesa();

            //Asignamos el id de la mesa recién guardada
            //en el id del objeto mesa_pedido que se llama detalle
            detalle.IdMesa = mesa.IdMesa;
            //También ya cargamos el id del mozo
            detalle.IdEmpleado = mesa.Mozo;

            //Recargamos la grilla
            string cadena = "select * from mesa_pedido;";
            CargarDatagridMesas(cadena);
            pnlMesas.Visible = false;
            //Dejamos seleccionada la mesa recién creada para que sea notorio que es la actualmente seleccinada

            //Verificamos que tenga filas cargadas
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[dataGridView1.RowCount - 1].Selected = true;
            }

            //Limpiamos los TextBox
            txtNombreMesa.Clear();

            //Actualizamos la grilla de los productos asociados a la mesa
            cadena = $"SELECT * FROM detalle WHERE id_mesa = {mesa.IdMesa}";
            CargarGrillaDetalle(cadena);

        }



        private void btnEliminarMesa_Click(object sender, EventArgs e)
        {
            detalle.EliminarDetalle();
            mesa.EliminarMesa();


            //Recargamos la grilla
            string cadena = "SELECT * FROM Mesa_pedido";
            CargarDatagridMesas(cadena);
        }



        private void CargarEmpleados()
        {
            cbxMozos.DataSource = null;
            cbxMozos.Items.Clear(); //limpia mi combo box
            string sql = "SELECT id_emp, nombre_emp FROM Empleados";
            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);
         
            cnx.Open();


            

            try
            {
                //Declaramos la variable para comandos
                MySqlCommand comando = new MySqlCommand(sql, cnx);
                comando.CommandType = CommandType.Text;//*
                MySqlDataAdapter data = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                data.Fill(dt);
                //Insertamos los datos

                cbxMozos.ValueMember = "id_emp";
                cbxMozos.DisplayMember = "nombre_emp";

                cbxMozos.DataSource = dt;

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al cargar Empleado" + ex.Message);
            }
            finally
            {
                cnx.Close();
            }

        }

        

        private void btnBuscarMesa_Click(object sender, EventArgs e)
        {
            string texto = txtBuscarMesa.Text;

            //Cadena de consulta
            string qry = $"SELECT * FROM Mesa_pedido WHERE nombre_mesa like '%{texto}%';";

            CargarDatagridMesas(qry);
        }



        private void dgvMesas_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //Obtenemos el Id del empleado en el que se hizo click
            string valor = dgvMesas.Rows[e.RowIndex].Cells["id_mesa"].Value.ToString();
            int valor_int = Int32.Parse(valor);
            mesa.IdMesa = valor_int;
            detalle.IdMesa = mesa.IdMesa;

            valor = dgvMesas.Rows[e.RowIndex].Cells["Mozo"].Value.ToString();
            valor_int = Int32.Parse(valor);
            detalle.IdEmpleado = valor_int;

            string cadena = $"SELECT * FROM detalle WHERE id_mesa = {mesa.IdMesa}";

            CargarGrillaDetalle(cadena);
            SumaTotal();
        }

        //-------------------------------------------------------------------//

        
        public void SumaTotal()
        {
            double total = 0;

            foreach (DataGridViewRow row in dgvDetalle.Rows)
            {
                total += Convert.ToDouble(row.Cells["SubTotal"].Value);
            }
            lblTotal.Text = total.ToString();
        }
       
        public void GuardarTotal()
        {

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);




            double total = 0;
            string mesaN = "";
            int codigo = 0;
            string fecha;
            fecha = DateTime.Today.ToString("yyyy/MM/dd");

            foreach (DataGridViewRow row in dgvDetalle.Rows)
            {
                total += Convert.ToDouble(row.Cells["SubTotal"].Value);
                
            }
            foreach (DataGridViewRow row in dgvMesas.Rows)
            {
                codigo = Convert.ToInt32(row.Cells["Mozo"].Value);
                mesaN = Convert.ToString(row.Cells["NombreMesa"].Value);
            }
            string insert = "INSERT INTO Caja" +
                            "(mesa, ingresos, codigo_Emp, egresos, TotalDia, fecha) " +
                            "VALUES " +
                            $"('{mesaN}', {total},{codigo},0, 0, '{fecha}');";
            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(insert, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);
            MessageBox.Show("El total a cobrar es " + total.ToString());
         
        }
 
        //----------------------------------------------------------------//
        //*****************     DETALLE   ********************************//
        //________________________________________________________________//

        private void CargarGrillaDetalle(string qry)
        {
            //Limpiamos el datagrid
            dgvDetalle.Rows.Clear();

            //Objeto de conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                // MessageBox.Show(dr["id_producto"].ToString());
                // MessageBox.Show(dr["id_mesa"].ToString());
                dgvDetalle.Rows.Add();
                dgvDetalle.Rows[fila].Cells["id_detalle"].Value = dr["id_detalle"].ToString();
                dgvDetalle.Rows[fila].Cells["cantidad"].Value = dr["cantidad"].ToString();
                dgvDetalle.Rows[fila].Cells["producto"].Value = dr["nombreProd"].ToString();
                dgvDetalle.Rows[fila].Cells["precio"].Value = dr["precioProd"].ToString();
                dgvDetalle.Rows[fila].Cells["SubTotal"].Value = dr["precioProd"].ToString();
                dgvDetalle.Rows[fila].Cells["id_producto"].Value = dr["id_producto"].ToString();
                dgvDetalle.Rows[fila].Cells["mes"].Value = dr["id_mesa"].ToString();

                fila++;
            }

        }



        //------------------------------------------------------------------//
        //************   PRODUCTOS-MERCADERIA  ****************************//
        //-------------------------------------------------------------------//


        public void CargarDataGridMercaderia(string qry)
        {
            //Limpiamos el datagrid
            dataGridView1.Rows.Clear();

            //Objeto de conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

            int fila = 0;

            //Recorro el dataset y cargo la grilla
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[fila].Cells["IdProducto"].Value = dr["id_prod"].ToString();
                dataGridView1.Rows[fila].Cells["Descripcion"].Value = dr["nom_prod"].ToString();
                dataGridView1.Rows[fila].Cells["PrecioProducto"].Value = dr["precio_prod"].ToString();

                fila++;
            }
        }



        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Obtenemos los datos del producto seleccionado
            string id_valor = dataGridView1.Rows[e.RowIndex].Cells["IdProducto"].Value.ToString();
            int valor_int = Int32.Parse(id_valor);
            detalle.IdProducto = valor_int;

            string descripcion_valor = dataGridView1.Rows[e.RowIndex].Cells["Descripcion"].Value.ToString();
            detalle.NombreProd = descripcion_valor;

            string precio_valor = dataGridView1.Rows[e.RowIndex].Cells["PrecioProducto"].Value.ToString();
            double precio_decimal = double.Parse(precio_valor);
            detalle.Precio = precio_decimal;


        }


        private void btnCargarAMesa_Click_1(object sender, EventArgs e)
        {
            //cargo cantidad de producto seleccionado
            if (dgvDetalle.SelectedRows.Count > 0 && txtCantidad.Text.Length > 0)
            {
                DataGridViewRow cant = dgvDetalle.CurrentRow;
                if (cant == null)
                {
                    return;
                }
                cant.Cells["Cantidad"].Value = txtCantidad.Text;
                cant.Cells["SubTotal"].Value = Convert.ToString(Convert.ToDecimal(cant.Cells["precio"].Value) * Convert.ToDecimal(txtCantidad.Text));

            }
            detalle.Cantidad = int.Parse(txtCantidad.Text);
            detalle.Precio = detalle.Precio * Convert.ToDouble(txtCantidad.Text);


            //Guardamos el producto en el detalle de la mesa
            detalle.Guardar();

            string cadena = $"SELECT * FROM detalle WHERE id_mesa = {mesa.IdMesa}";
            CargarGrillaDetalle(cadena);
            SumaTotal();

            //Hacemos que no haya ninguna fila auto seleccionada
            dataGridView1.ClearSelection();


        }





        private void dgvDetalle_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Obtenemos el Id del producto en el que se hizo click
            string valor = dgvDetalle.Rows[e.RowIndex].Cells["id_producto"].Value.ToString();
            string valor1 = dgvDetalle.Rows[e.RowIndex].Cells["mes"].Value.ToString();
            int valor_int = Int32.Parse(valor);
            int valor1_int = Int32.Parse(valor1);
            detalle.IdProducto = valor_int;
            detalle.IdMesa = valor1_int;
        }

        private void btnCobrar_Click(object sender, EventArgs e)
        {
            string cadena = $"select * from Detalle where id_mesa = {this.detalle.IdMesa};";
            string qry = $"select * from Mesa_pedido;";
            GuardarTotal();
            
           detalle.EliminarDetalle();
            mesa.EliminarMesa();
            CargarGrillaDetalle(cadena);
            CargarDatagridMesas(qry);

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            detalle.Eliminar();
            string cadena = $"select * from Detalle where id_mesa ={this.detalle.IdMesa};";

            CargarGrillaDetalle(cadena);
            SumaTotal();
        }
    }



    //--------------------------------------------------------------------//

    public class Mesas_Pedidos
    {
        //Atributos de la clase
        int _idMesa;
        string _nombreMesa;
        int _mozo;

        //Metodos SET y GET

        public int IdMesa
        {
            get { return _idMesa; }
            set { _idMesa = value; }
        }
        public string NombreMesa
        {
            get { return _nombreMesa; }
            set { _nombreMesa = value; }
        }
        public int Mozo
        {
            get { return _mozo; }
            set { _mozo = value; }
        }

        //contructor por defecto
        public Mesas_Pedidos()
        {
            this._idMesa = 0;
            this._nombreMesa = "";
            this._mozo = 0;
        }

       
        public void GuardarMesa()
        {
            string cadena = "INSERT INTO Mesa_Pedido " +
                            "(nombre_mesa, id_empleado) " +
                            "VALUES " +
                            $"('{this._nombreMesa}', {this._mozo});";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(cadena, cnx);

            try
            {
                cnx.Open();

                //Insertamos los datos
                comando.ExecuteNonQuery();

                //Recuperamos el ID recién asignado por la DB
                cadena = "SELECT LAST_INSERT_ID() FROM mesa_pedido;";
                try
                {
                    MySqlCommand comando2 = new MySqlCommand(cadena, cnx);
                    int IdMesa = Convert.ToInt32(comando2.ExecuteScalar());

                    //Le asignamos el id al objeto para poderlo tomar en la
                    //llamada al método
                    this.IdMesa = IdMesa;

                    string cadena_1 = $"SELECT id_empleado FROM mesa_pedido WHERE id_mesa = {IdMesa}";
                    MySqlCommand comando_3 = new MySqlCommand(cadena_1, cnx);
                    int id_mozo = Convert.ToInt32(comando_3.ExecuteScalar());
                    this.Mozo = id_mozo;

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }



        public void EliminarMesa()
        {
            //Cadena de consulta
            string qry = $"DELETE FROM Mesa_Pedido WHERE id_mesa = {this._idMesa};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);

            try
            {
                cnx.Open();

                //Ejecutamos la consulta
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }

        }



        public void CargarDatosMesa()
        {
            //Cadena de consulta
            string qry = $"SELECT * FROM Mesa_Pedido WHERE id_mesa = {this._idMesa}";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Traemos los datos
            MySqlDataAdapter data = new MySqlDataAdapter(qry, cnx);
            DataSet ds = new DataSet();
            data.Fill(ds);

            //Asignamos los valores
            DataRow dr = ds.Tables[0].Rows[0];
           
            this._nombreMesa = dr["nombre_mesa"].ToString();
            this._mozo = (int)dr["id_empleado"];

        }
        public void ActualizarMesa()
        {
            string qry = $"UPDATE Mesa_Pedido SET nombre_mesa = '{this._nombreMesa}', id_empleado = '{this._mozo}' WHERE id_mesa = {this._idMesa};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);

            try
            {
                cnx.Open();

                //Insertamos los datos
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }


    }



    //--------------------------------------------------------------------------------------//
    //--------------------------------------------------------------------------------------//
    public class DetalleMesa
    {
        //Atributos de la clase 
        private int _idDetalle;
        
        private int _IdMesa;
        private int _IdEmpleado;
        private int _idProducto;
        private string _nombreProd;
        private int _cantidad;
        private double _precio;
       
        public int IDDetalle
        {
            get { return _idDetalle; }
            set { _idDetalle = value; }
        }

     

        public int IdMesa
        {
            get { return _IdMesa; }
            set { _IdMesa = value; }
        }

        public int IdEmpleado
        {
            get { return _IdEmpleado; }
            set { _IdEmpleado = value; }
        }

        public int IdProducto
        {
            get { return _idProducto; }
            set { _idProducto = value; }
        }

        public string NombreProd
        {
            get { return _nombreProd; }
            set { _nombreProd = value; }
        }

        public int Cantidad
        {
            get { return _cantidad; }
            set { _cantidad = value; }
        }

        public double Precio
        {
            get { return _precio; }
            set { _precio = value; }
        }

        //contructor
        public DetalleMesa()
        {
            _idDetalle = 0;
            
            _IdMesa = 0;
            _IdEmpleado = 0;
            _idProducto = 0;
            _nombreProd = "";
            _cantidad = 0;
            _precio = 0;
            
        }



        public void Guardar()
        {
            string cadena = "INSERT INTO Detalle " +
                            "( cantidad, id_mesa, id_empleado," +
                            " id_producto, nombreProd, precioProd) " +
                            "VALUES " +
                            $"('{this._cantidad}', '{this._IdMesa}'," +
                            $" '{this.IdEmpleado}', '{this.IdProducto}', '{this.NombreProd}'," +
                            $" '{this._precio}');";


            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(cadena, cnx);

            try
            {
                cnx.Open();

                //Insertamos los datos
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }







        public void Actualizar()
        {
            string qry = $"UPDATE Detalle SET  cantidad = '{this._cantidad}', id_mesa = '{this._IdMesa}', id_producto = {this._idProducto}' WHERE id_detalle = {this._idDetalle};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);

            try
            {
                cnx.Open();

                //Insertamos los datos
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }

        public void Eliminar()
        {
            //Cadena de consulta
            string qry = $"DELETE FROM Detalle WHERE id_producto = {this._idProducto} and id_mesa = {this._IdMesa};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);

            try
            {
                cnx.Open();

                //Ejecutamos la consulta
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }
        public void EliminarDetalle()
        {
            //Cadena de consulta
            string qry = $"DELETE FROM Detalle WHERE  id_mesa = {this._IdMesa};";

            //Creamos el objeto para la conexión
            MySqlConnection cnx = new MySqlConnection(Conexion.ConnectionString);

            //Declaramos la variable para comandos
            MySqlCommand comando = new MySqlCommand(qry, cnx);

            try
            {
                cnx.Open();

                //Ejecutamos la consulta
                comando.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cnx.Close();
            }
        }


    }
}
