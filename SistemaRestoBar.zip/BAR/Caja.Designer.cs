﻿namespace BAR
{
    partial class Caja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvCaja = new System.Windows.Forms.DataGridView();
            this.mesa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_mozo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ingresos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gasto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Detalle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSalirCaja = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDetalle = new System.Windows.Forms.TextBox();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.btnGuardarGasto = new System.Windows.Forms.Button();
            this.btnCerrarCaja = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblGastos = new System.Windows.Forms.Label();
            this.lblTotalDia = new System.Windows.Forms.Label();
            this.dgvTotales = new System.Windows.Forms.DataGridView();
            this.Fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ingreso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gastos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCaja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTotales)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvCaja
            // 
            this.dgvCaja.AllowUserToAddRows = false;
            this.dgvCaja.AllowUserToDeleteRows = false;
            this.dgvCaja.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCaja.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mesa,
            this.id_mozo,
            this.ingresos,
            this.gasto,
            this.Detalle});
            this.dgvCaja.Location = new System.Drawing.Point(-1, 47);
            this.dgvCaja.Name = "dgvCaja";
            this.dgvCaja.ReadOnly = true;
            this.dgvCaja.Size = new System.Drawing.Size(559, 360);
            this.dgvCaja.TabIndex = 1;
            // 
            // mesa
            // 
            this.mesa.HeaderText = "Nombre de mesa/ pedido";
            this.mesa.Name = "mesa";
            this.mesa.ReadOnly = true;
            this.mesa.Width = 160;
            // 
            // id_mozo
            // 
            this.id_mozo.HeaderText = "Codigo de Mozo";
            this.id_mozo.Name = "id_mozo";
            this.id_mozo.ReadOnly = true;
            this.id_mozo.Width = 70;
            // 
            // ingresos
            // 
            this.ingresos.HeaderText = "Total cobrado";
            this.ingresos.Name = "ingresos";
            this.ingresos.ReadOnly = true;
            this.ingresos.Width = 70;
            // 
            // gasto
            // 
            this.gasto.HeaderText = "Gastos";
            this.gasto.Name = "gasto";
            this.gasto.ReadOnly = true;
            this.gasto.Width = 70;
            // 
            // Detalle
            // 
            this.Detalle.HeaderText = "Detalle de gastos";
            this.Detalle.Name = "Detalle";
            this.Detalle.ReadOnly = true;
            this.Detalle.Width = 150;
            // 
            // btnSalirCaja
            // 
            this.btnSalirCaja.BackColor = System.Drawing.Color.Crimson;
            this.btnSalirCaja.Location = new System.Drawing.Point(803, 505);
            this.btnSalirCaja.Name = "btnSalirCaja";
            this.btnSalirCaja.Size = new System.Drawing.Size(75, 23);
            this.btnSalirCaja.TabIndex = 19;
            this.btnSalirCaja.Text = "Salir";
            this.btnSalirCaja.UseVisualStyleBackColor = false;
            this.btnSalirCaja.Click += new System.EventHandler(this.btnSalirCaja_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(171, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Ingresos del dia";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(122, 492);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Total del dia  $";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(190, 20);
            this.label3.TabIndex = 24;
            this.label3.Text = "Agregar gastos del dia";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(631, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 25;
            this.label4.Text = "Detalle";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "Monto";
            // 
            // txtDetalle
            // 
            this.txtDetalle.Location = new System.Drawing.Point(33, 39);
            this.txtDetalle.Name = "txtDetalle";
            this.txtDetalle.Size = new System.Drawing.Size(211, 20);
            this.txtDetalle.TabIndex = 27;
            // 
            // txtMonto
            // 
            this.txtMonto.Location = new System.Drawing.Point(72, 74);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(100, 20);
            this.txtMonto.TabIndex = 28;
            // 
            // btnGuardarGasto
            // 
            this.btnGuardarGasto.BackColor = System.Drawing.Color.GreenYellow;
            this.btnGuardarGasto.Location = new System.Drawing.Point(189, 88);
            this.btnGuardarGasto.Name = "btnGuardarGasto";
            this.btnGuardarGasto.Size = new System.Drawing.Size(82, 32);
            this.btnGuardarGasto.TabIndex = 29;
            this.btnGuardarGasto.Text = "Guardar gasto";
            this.btnGuardarGasto.UseVisualStyleBackColor = false;
            this.btnGuardarGasto.Click += new System.EventHandler(this.btnGuardarGasto_Click);
            // 
            // btnCerrarCaja
            // 
            this.btnCerrarCaja.BackColor = System.Drawing.Color.DarkCyan;
            this.btnCerrarCaja.Location = new System.Drawing.Point(255, 452);
            this.btnCerrarCaja.Name = "btnCerrarCaja";
            this.btnCerrarCaja.Size = new System.Drawing.Size(112, 23);
            this.btnCerrarCaja.TabIndex = 30;
            this.btnCerrarCaja.Text = "Cerrar caja del dia";
            this.btnCerrarCaja.UseVisualStyleBackColor = false;
            this.btnCerrarCaja.Click += new System.EventHandler(this.btnCerrarCaja_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.LightCyan;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(273, 410);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(15, 16);
            this.lblTotal.TabIndex = 31;
            this.lblTotal.Text = "$";
            // 
            // lblGastos
            // 
            this.lblGastos.AutoSize = true;
            this.lblGastos.BackColor = System.Drawing.Color.LightCyan;
            this.lblGastos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGastos.Location = new System.Drawing.Point(352, 410);
            this.lblGastos.Name = "lblGastos";
            this.lblGastos.Size = new System.Drawing.Size(15, 16);
            this.lblGastos.TabIndex = 32;
            this.lblGastos.Text = "$";
            // 
            // lblTotalDia
            // 
            this.lblTotalDia.AutoSize = true;
            this.lblTotalDia.BackColor = System.Drawing.Color.LightCyan;
            this.lblTotalDia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalDia.Location = new System.Drawing.Point(246, 492);
            this.lblTotalDia.Name = "lblTotalDia";
            this.lblTotalDia.Size = new System.Drawing.Size(19, 20);
            this.lblTotalDia.TabIndex = 33;
            this.lblTotalDia.Text = "$";
            // 
            // dgvTotales
            // 
            this.dgvTotales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTotales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Fecha,
            this.ingreso,
            this.gastos,
            this.total});
            this.dgvTotales.Location = new System.Drawing.Point(573, 276);
            this.dgvTotales.Name = "dgvTotales";
            this.dgvTotales.Size = new System.Drawing.Size(345, 150);
            this.dgvTotales.TabIndex = 34;
            // 
            // Fecha
            // 
            this.Fecha.HeaderText = "Fecha";
            this.Fecha.Name = "Fecha";
            // 
            // ingreso
            // 
            this.ingreso.HeaderText = "Ingresos";
            this.ingreso.Name = "ingreso";
            this.ingreso.Width = 70;
            // 
            // gastos
            // 
            this.gastos.HeaderText = "Gastos";
            this.gastos.Name = "gastos";
            this.gastos.Width = 70;
            // 
            // total
            // 
            this.total.HeaderText = "Total del dia";
            this.total.Name = "total";
            this.total.Width = 70;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtDetalle);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtMonto);
            this.panel1.Controls.Add(this.btnGuardarGasto);
            this.panel1.Location = new System.Drawing.Point(593, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(285, 147);
            this.panel1.TabIndex = 35;
            // 
            // Caja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(930, 552);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvTotales);
            this.Controls.Add(this.lblTotalDia);
            this.Controls.Add(this.lblGastos);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnCerrarCaja);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSalirCaja);
            this.Controls.Add(this.dgvCaja);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Caja";
            this.Text = "Caja";
            this.Load += new System.EventHandler(this.Caja_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCaja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTotales)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvCaja;
        private System.Windows.Forms.Button btnSalirCaja;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDetalle;
        private System.Windows.Forms.TextBox txtMonto;
        private System.Windows.Forms.Button btnGuardarGasto;
        private System.Windows.Forms.Button btnCerrarCaja;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblGastos;
        private System.Windows.Forms.Label lblTotalDia;
        private System.Windows.Forms.DataGridViewTextBoxColumn mesa;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_mozo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ingresos;
        private System.Windows.Forms.DataGridViewTextBoxColumn gasto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Detalle;
        private System.Windows.Forms.DataGridView dgvTotales;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn ingreso;
        private System.Windows.Forms.DataGridViewTextBoxColumn gastos;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private System.Windows.Forms.Panel panel1;
    }
}