﻿namespace BAR
{
    partial class Mesas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvMesas = new System.Windows.Forms.DataGridView();
            this.id_mesa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NombreMesa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mozo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAgregarMesa = new System.Windows.Forms.Button();
            this.pnlMesas = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxMozos = new System.Windows.Forms.ComboBox();
            this.btnOkMesa = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombreMesa = new System.Windows.Forms.TextBox();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.btnCobrar = new System.Windows.Forms.Button();
            this.dgvDetalle = new System.Windows.Forms.DataGridView();
            this.id_detalle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_producto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.producto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEliminarMesa = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SalirMesas = new System.Windows.Forms.Button();
            this.btnBuscarMesa = new System.Windows.Forms.Button();
            this.txtBuscarMesa = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idProducto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrecioProducto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCargarAMesa = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMesas)).BeginInit();
            this.pnlMesas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvMesas
            // 
            this.dgvMesas.AllowUserToAddRows = false;
            this.dgvMesas.AllowUserToDeleteRows = false;
            this.dgvMesas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMesas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_mesa,
            this.NombreMesa,
            this.Mozo});
            this.dgvMesas.Location = new System.Drawing.Point(12, 3);
            this.dgvMesas.Name = "dgvMesas";
            this.dgvMesas.ReadOnly = true;
            this.dgvMesas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMesas.Size = new System.Drawing.Size(234, 381);
            this.dgvMesas.TabIndex = 2;
            this.dgvMesas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMesas_CellClick_1);
            // 
            // id_mesa
            // 
            this.id_mesa.HeaderText = "id_mesa";
            this.id_mesa.Name = "id_mesa";
            this.id_mesa.ReadOnly = true;
            this.id_mesa.Visible = false;
            this.id_mesa.Width = 50;
            // 
            // NombreMesa
            // 
            this.NombreMesa.HeaderText = "Mesas / Pedidos";
            this.NombreMesa.Name = "NombreMesa";
            this.NombreMesa.ReadOnly = true;
            this.NombreMesa.Width = 120;
            // 
            // Mozo
            // 
            this.Mozo.HeaderText = "Codigo de empleado";
            this.Mozo.Name = "Mozo";
            this.Mozo.ReadOnly = true;
            this.Mozo.Width = 70;
            // 
            // btnAgregarMesa
            // 
            this.btnAgregarMesa.BackColor = System.Drawing.Color.DarkCyan;
            this.btnAgregarMesa.Location = new System.Drawing.Point(247, 52);
            this.btnAgregarMesa.Name = "btnAgregarMesa";
            this.btnAgregarMesa.Size = new System.Drawing.Size(109, 51);
            this.btnAgregarMesa.TabIndex = 3;
            this.btnAgregarMesa.Text = "Agregar mesa/pedido";
            this.btnAgregarMesa.UseVisualStyleBackColor = false;
            this.btnAgregarMesa.Click += new System.EventHandler(this.btnAgregarMesa_Click);
            // 
            // pnlMesas
            // 
            this.pnlMesas.Controls.Add(this.label4);
            this.pnlMesas.Controls.Add(this.cbxMozos);
            this.pnlMesas.Controls.Add(this.btnOkMesa);
            this.pnlMesas.Controls.Add(this.label1);
            this.pnlMesas.Controls.Add(this.txtNombreMesa);
            this.pnlMesas.Location = new System.Drawing.Point(252, 109);
            this.pnlMesas.Name = "pnlMesas";
            this.pnlMesas.Size = new System.Drawing.Size(228, 149);
            this.pnlMesas.TabIndex = 4;
            this.pnlMesas.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Mozo o Delivery";
            // 
            // cbxMozos
            // 
            this.cbxMozos.FormattingEnabled = true;
            this.cbxMozos.Location = new System.Drawing.Point(26, 79);
            this.cbxMozos.Name = "cbxMozos";
            this.cbxMozos.Size = new System.Drawing.Size(130, 21);
            this.cbxMozos.TabIndex = 19;
            // 
            // btnOkMesa
            // 
            this.btnOkMesa.BackColor = System.Drawing.Color.GreenYellow;
            this.btnOkMesa.Location = new System.Drawing.Point(67, 109);
            this.btnOkMesa.Name = "btnOkMesa";
            this.btnOkMesa.Size = new System.Drawing.Size(75, 23);
            this.btnOkMesa.TabIndex = 6;
            this.btnOkMesa.Text = "OK";
            this.btnOkMesa.UseVisualStyleBackColor = false;
            this.btnOkMesa.Click += new System.EventHandler(this.btnOkMesa_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nombre de mesa o pedido";
            // 
            // txtNombreMesa
            // 
            this.txtNombreMesa.Location = new System.Drawing.Point(22, 27);
            this.txtNombreMesa.Name = "txtNombreMesa";
            this.txtNombreMesa.Size = new System.Drawing.Size(155, 20);
            this.txtNombreMesa.TabIndex = 4;
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(870, 414);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(100, 20);
            this.txtCantidad.TabIndex = 14;
            this.txtCantidad.Text = "1";
            // 
            // btnCobrar
            // 
            this.btnCobrar.BackColor = System.Drawing.Color.GreenYellow;
            this.btnCobrar.Location = new System.Drawing.Point(593, 294);
            this.btnCobrar.Name = "btnCobrar";
            this.btnCobrar.Size = new System.Drawing.Size(105, 23);
            this.btnCobrar.TabIndex = 12;
            this.btnCobrar.Text = "Cobrar pedido";
            this.btnCobrar.UseVisualStyleBackColor = false;
            this.btnCobrar.Click += new System.EventHandler(this.btnCobrar_Click);
            // 
            // dgvDetalle
            // 
            this.dgvDetalle.AccessibleDescription = "";
            this.dgvDetalle.AllowUserToAddRows = false;
            this.dgvDetalle.AllowUserToDeleteRows = false;
            this.dgvDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalle.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_detalle,
            this.mes,
            this.id_producto,
            this.producto,
            this.cantidad,
            this.SubTotal,
            this.precio});
            this.dgvDetalle.Location = new System.Drawing.Point(486, 12);
            this.dgvDetalle.Name = "dgvDetalle";
            this.dgvDetalle.ReadOnly = true;
            this.dgvDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetalle.Size = new System.Drawing.Size(288, 229);
            this.dgvDetalle.TabIndex = 10;
            this.dgvDetalle.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDetalle_CellClick);
            // 
            // id_detalle
            // 
            this.id_detalle.HeaderText = "id_detalle";
            this.id_detalle.Name = "id_detalle";
            this.id_detalle.ReadOnly = true;
            this.id_detalle.Visible = false;
            this.id_detalle.Width = 50;
            // 
            // mes
            // 
            this.mes.HeaderText = "id_mesa";
            this.mes.Name = "mes";
            this.mes.ReadOnly = true;
            this.mes.Visible = false;
            // 
            // id_producto
            // 
            this.id_producto.HeaderText = "id_prod";
            this.id_producto.Name = "id_producto";
            this.id_producto.ReadOnly = true;
            this.id_producto.Visible = false;
            // 
            // producto
            // 
            this.producto.HeaderText = "Producto";
            this.producto.Name = "producto";
            this.producto.ReadOnly = true;
            // 
            // cantidad
            // 
            this.cantidad.HeaderText = "Cantidad";
            this.cantidad.Name = "cantidad";
            this.cantidad.ReadOnly = true;
            this.cantidad.Width = 70;
            // 
            // SubTotal
            // 
            this.SubTotal.HeaderText = "SubTotal";
            this.SubTotal.Name = "SubTotal";
            this.SubTotal.ReadOnly = true;
            this.SubTotal.Width = 80;
            // 
            // precio
            // 
            this.precio.HeaderText = "precio";
            this.precio.Name = "precio";
            this.precio.ReadOnly = true;
            this.precio.Visible = false;
            this.precio.Width = 50;
            // 
            // btnEliminarMesa
            // 
            this.btnEliminarMesa.BackColor = System.Drawing.Color.Salmon;
            this.btnEliminarMesa.Location = new System.Drawing.Point(94, 440);
            this.btnEliminarMesa.Name = "btnEliminarMesa";
            this.btnEliminarMesa.Size = new System.Drawing.Size(126, 23);
            this.btnEliminarMesa.TabIndex = 17;
            this.btnEliminarMesa.Text = "Eliminar pedido";
            this.btnEliminarMesa.UseVisualStyleBackColor = false;
            this.btnEliminarMesa.Click += new System.EventHandler(this.btnEliminarMesa_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(815, 418);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Cnatidad";
            // 
            // SalirMesas
            // 
            this.SalirMesas.BackColor = System.Drawing.Color.Crimson;
            this.SalirMesas.Location = new System.Drawing.Point(915, 469);
            this.SalirMesas.Name = "SalirMesas";
            this.SalirMesas.Size = new System.Drawing.Size(75, 23);
            this.SalirMesas.TabIndex = 18;
            this.SalirMesas.Text = "Salir";
            this.SalirMesas.UseVisualStyleBackColor = false;
            this.SalirMesas.Click += new System.EventHandler(this.SalirMesas_Click);
            // 
            // btnBuscarMesa
            // 
            this.btnBuscarMesa.BackColor = System.Drawing.Color.GreenYellow;
            this.btnBuscarMesa.Location = new System.Drawing.Point(180, 411);
            this.btnBuscarMesa.Name = "btnBuscarMesa";
            this.btnBuscarMesa.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarMesa.TabIndex = 19;
            this.btnBuscarMesa.Text = "Buscar";
            this.btnBuscarMesa.UseVisualStyleBackColor = false;
            this.btnBuscarMesa.Click += new System.EventHandler(this.btnBuscarMesa_Click);
            // 
            // txtBuscarMesa
            // 
            this.txtBuscarMesa.Location = new System.Drawing.Point(38, 411);
            this.txtBuscarMesa.Name = "txtBuscarMesa";
            this.txtBuscarMesa.Size = new System.Drawing.Size(136, 20);
            this.txtBuscarMesa.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(578, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "Total $";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idProducto,
            this.Descripcion,
            this.PrecioProducto});
            this.dataGridView1.Location = new System.Drawing.Point(790, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(200, 406);
            this.dataGridView1.TabIndex = 23;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // idProducto
            // 
            this.idProducto.HeaderText = "idProducto";
            this.idProducto.Name = "idProducto";
            this.idProducto.ReadOnly = true;
            this.idProducto.Visible = false;
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Producto";
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.ReadOnly = true;
            // 
            // PrecioProducto
            // 
            this.PrecioProducto.HeaderText = "Precio";
            this.PrecioProducto.Name = "PrecioProducto";
            this.PrecioProducto.ReadOnly = true;
            // 
            // btnCargarAMesa
            // 
            this.btnCargarAMesa.BackColor = System.Drawing.Color.GreenYellow;
            this.btnCargarAMesa.Location = new System.Drawing.Point(802, 440);
            this.btnCargarAMesa.Name = "btnCargarAMesa";
            this.btnCargarAMesa.Size = new System.Drawing.Size(103, 23);
            this.btnCargarAMesa.TabIndex = 25;
            this.btnCargarAMesa.Text = "Cargar al pedido";
            this.btnCargarAMesa.UseVisualStyleBackColor = false;
            this.btnCargarAMesa.Click += new System.EventHandler(this.btnCargarAMesa_Click_1);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(650, 262);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 13);
            this.lblTotal.TabIndex = 26;
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.Salmon;
            this.btnEliminar.Location = new System.Drawing.Point(486, 251);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 35);
            this.btnEliminar.TabIndex = 27;
            this.btnEliminar.Text = "Eliminar Producto";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // Mesas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1002, 504);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnCargarAMesa);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBuscarMesa);
            this.Controls.Add(this.btnBuscarMesa);
            this.Controls.Add(this.SalirMesas);
            this.Controls.Add(this.btnEliminarMesa);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.btnCobrar);
            this.Controls.Add(this.dgvDetalle);
            this.Controls.Add(this.pnlMesas);
            this.Controls.Add(this.btnAgregarMesa);
            this.Controls.Add(this.dgvMesas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Mesas";
            this.Text = "Mesas";
            this.Load += new System.EventHandler(this.Mesas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMesas)).EndInit();
            this.pnlMesas.ResumeLayout(false);
            this.pnlMesas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvMesas;
        private System.Windows.Forms.Button btnAgregarMesa;
        private System.Windows.Forms.Panel pnlMesas;
        private System.Windows.Forms.Button btnOkMesa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombreMesa;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Button btnCobrar;
        private System.Windows.Forms.DataGridView dgvDetalle;
        private System.Windows.Forms.Button btnEliminarMesa;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SalirMesas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxMozos;
        private System.Windows.Forms.Button btnBuscarMesa;
        private System.Windows.Forms.TextBox txtBuscarMesa;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProducto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrecioProducto;
        private System.Windows.Forms.Button btnCargarAMesa;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_detalle;
        private System.Windows.Forms.DataGridViewTextBoxColumn mes;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_producto;
        private System.Windows.Forms.DataGridViewTextBoxColumn producto;
        private System.Windows.Forms.DataGridViewTextBoxColumn cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn precio;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_mesa;
        private System.Windows.Forms.DataGridViewTextBoxColumn NombreMesa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mozo;
    }
}