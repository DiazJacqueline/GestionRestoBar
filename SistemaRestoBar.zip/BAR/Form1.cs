﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace BAR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnMaximizar.Visible = false;
            btnRestaurar.Visible = true;
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnRestaurar.Visible = false;
            btnMaximizar.Visible = true;

        }

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lParam);

        private void BarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012,0);
        }

        

     private void AbrirOtroFormulario(object AbrirFormulario)
        {
          if (this.panelContenedor.Controls.Count > 0)
             this.panelContenedor.Controls.RemoveAt(0);
            Form Agregar = AbrirFormulario as Form; //al objeto creado lo converti en el formulario
            Agregar.TopLevel = false; //no es un formulario de nivel superior (secundario)
            Agregar.Dock = DockStyle.Fill; //para que se acople a todo el panel contenedor
            this.panelContenedor.Controls.Add(Agregar); //Se agrega al panel contenedor ("principal")
            this.panelContenedor.Tag = Agregar; //se establece la instancia como contenedor de datos
            Agregar.Show(); //se muestra el panel
        }
      

    



        private void btnProducto_Click(object sender, EventArgs e)
        {
            // SubMenuProd.Visible = true;
            SubmenuProductos.Visible = false;
            AbrirOtroFormulario(new Productos());
        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {

            AbrirOtroFormulario(new FormEmpleados());
        }

        private void button8_Click(object sender, EventArgs e)
        {
            
            AbrirOtroFormulario(new Mesas());
        }

        private void caja_Click(object sender, EventArgs e)
        {
            AbrirOtroFormulario(new Caja());
        }
    }

    }
